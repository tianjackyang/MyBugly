#import <UIKit/UIKit.h>

@interface YDSDKPlatformPayParamModel : NSObject

@property (nonatomic, strong) NSString * accountId;
@property (nonatomic, strong) NSString * currencyType;
@property (nonatomic, strong) NSString * gameAccountId;
@property (nonatomic, strong) NSString * gameId;
@property (nonatomic, strong) NSString * money;
@property (nonatomic, strong) NSString * orderItem;
// 订单明细签名，签名算法和私钥联系后端获取
@property (nonatomic, strong) NSString * orderSign;
@property (nonatomic, strong) NSString * outOrderNo;
@property (nonatomic, strong) NSString * roleId;
@property (nonatomic, assign) NSInteger serverId;
// 冰川的订单流水号
@property (nonatomic, strong) NSString *bcSerialNo;
    // 自定义透传字段，必须是有效json格式字符串，并且使用 URL Encode UTF-8 编码
@property (nonatomic, strong) NSString *developerPayload;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

-(NSDictionary *)toDictionary;
@end
