#import <UIKit/UIKit.h>

@interface YDSDKGetGameLastRoleInfo : NSObject

@property (nonatomic, assign) NSInteger accountId;
@property (nonatomic, strong) NSString * createTime;
@property (nonatomic, assign) NSInteger frozenStatus;
@property (nonatomic, assign) NSInteger gameAccountId;
@property (nonatomic, assign) NSInteger gameId;
@property (nonatomic, assign) NSInteger gameServerId;
@property (nonatomic, assign) NSInteger headAdminAccount;
@property (nonatomic, assign) NSInteger inviterAdminAccount;
@property (nonatomic, assign) NSInteger isValid;
@property (nonatomic, strong) NSString * roleId;
@property (nonatomic, assign) NSInteger roleLevel;
@property (nonatomic, strong) NSString * roleName;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

-(NSDictionary *)toDictionary;
@end