#import <UIKit/UIKit.h>
#import "YDSDKGetGameLastRoleInfo.h"

@interface YDSDKGetGameData : NSObject

@property (nonatomic, assign) NSInteger accountId;
@property (nonatomic, assign) NSInteger createTime;
@property (nonatomic, assign) NSInteger frozenStatus; // 0 合法 1 冻结
@property (nonatomic, assign) NSInteger gameAccountId;
@property (nonatomic, strong) NSString * gameArea;
@property (nonatomic, strong) NSString * gameId;
@property (nonatomic, assign) NSInteger gameStatus; // 0 空闲 1 游戏中
@property (nonatomic, assign) NSInteger inviterAdminAccountId;
@property (nonatomic, strong) YDSDKGetGameLastRoleInfo * lastRoleInfo;
@property (nonatomic, assign) NSInteger roleCount;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

-(NSDictionary *)toDictionary;
@end
