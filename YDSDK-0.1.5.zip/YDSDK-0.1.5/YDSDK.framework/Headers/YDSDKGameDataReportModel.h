#import <UIKit/UIKit.h>
#import "YDSDKGameDataReportExpandedData.h"

@interface YDSDKGameDataReportModel : NSObject
// 主账户id()
@property (nonatomic, assign) NSInteger accountId;
@property (nonatomic, strong) YDSDKGameDataReportExpandedData * expandedData;
// 游戏账户id
@property (nonatomic, assign) NSInteger gameAccountId;
// 游戏id (从全局配置中自动读取)
@property (nonatomic, strong) NSString * gameId;
// 游戏名称 (从全局配置中自动读取)
@property (nonatomic, strong) NSString * gameName;
// 游戏区服id
@property (nonatomic, assign) NSInteger gameServerId;
// 游戏区服名称
@property (nonatomic, strong) NSString * gameServerName;
// 角色id
@property (nonatomic, strong) NSString * roleId;
// 角色等级
@property (nonatomic, strong) NSString * roleLevel;
// 角色名称(如果Event是ROLE_CHANGE_NAME，则roleName是修改后的角色名称)
@property (nonatomic, strong) NSString * roleName;
@property (nonatomic, assign) NSInteger time;
// 事件类型(枚举name值，例：EventType.LOGIN_GAME.name)
@property (nonatomic, strong) NSString * type;
// 每次请求对应的唯一Id
@property (nonatomic, strong) NSString * uuid;
// 事件对应的参数(目前用不到)
@property (nonatomic, strong) NSString * value;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

-(NSDictionary *)toDictionary;
@end
