#import <UIKit/UIKit.h>

@interface YDSDKGetGameLastRoleInfo : NSObject

//主账户ID
@property (nonatomic, assign) NSInteger accountId;
//角色创建时间
@property (nonatomic, strong) NSString * createTime;
//角色状态
@property (nonatomic, assign) NSInteger frozenStatus;
//游戏账户ID
@property (nonatomic, assign) NSInteger gameAccountId;
//游戏ID
@property (nonatomic, assign) NSInteger gameId;
//游戏区服ID
@property (nonatomic, assign) NSInteger gameServerId;
//团长后台账户ID
@property (nonatomic, assign) NSInteger headAdminAccount;
//推广后台账户ID
@property (nonatomic, assign) NSInteger inviterAdminAccount;
//有效状态
@property (nonatomic, assign) NSInteger isValid;
//角色ID
@property (nonatomic, strong) NSString * roleId;
//角色等级
@property (nonatomic, assign) NSInteger roleLevel;
//角色名称
@property (nonatomic, strong) NSString * roleName;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

-(NSDictionary *)toDictionary;
@end
