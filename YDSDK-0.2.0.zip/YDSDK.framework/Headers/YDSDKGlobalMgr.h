//
//  YDSDKGlobalMgr.h
//  YDSDK
//
//  Created by mac on 2023/2/16.
//

#import <Foundation/Foundation.h>
#import "YDSDKPlatformPayParamModel.h"
#import "YDSDKGetGameData.h"
#import "YDSDKGameDataReportModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, YDSDKInterfaceType) {
    YDSDKInterfaceType_LoginOrRegister, //注册登陆
    YDSDKInterfaceType_AssociateTouch, //悬浮按钮
    YDSDKInterfaceType_LoginLoading, // 登陆Loading
    YDSDKInterfaceType_Setting, // 设置
    YDSDKInterfaceType_SwitchLoading, //切换账号Loading
    YDSDKInterfaceType_FrozenSwitch, // 冻结账号
    YDSDKInterfaceType_Pay, // 支付
    YDSDKInterfaceType_PaySuccess, //支付成功
    YDSDKInterfaceType_PayFailure, //支付失败
    YDSDKInterfaceType_PayNotice, //支付状态
};

typedef void (^SwitchGameAccountBlock) (YDSDKGetGameData *data);

@interface YDSDKGlobalMgr : NSObject

+ (instancetype)shareInstance;

- (void)showAssociateTouch:(BOOL)show;

- (void)pushViewControllerWithType:(YDSDKInterfaceType)type;

- (void)pushViewControllerWithType:(YDSDKInterfaceType)type
                          withData:(YDSDKPlatformPayParamModel*)model
                        withScheme:(NSString*)scheme;

- (void)handleopenURL:(NSURL *)url;

// 切换游戏账号回调
@property (nonatomic, copy) SwitchGameAccountBlock switchGameAccountBlock;

// 上报游戏数据
- (void)upLoadGameDataReport:(YDSDKGameDataReportModel*)model;

// 注销账户
- (void)logout;
@end

NS_ASSUME_NONNULL_END
