//
//  YDSDKGlobalMgr.h
//  YDSDK
//
//  Created by mac on 2023/2/16.
//

#import <Foundation/Foundation.h>
#import "YDSDKPlatformPayParamModel.h"
#import "YDSDKGetGameData.h"
#import "YDSDKGameDataReportModel.h"
#import "YDSDKLoginData.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, YDSDKInterfaceType) {
    YDSDKInterfaceType_LoginOrRegister, //注册登陆
    YDSDKInterfaceType_AssociateTouch, //悬浮按钮
    YDSDKInterfaceType_Pay, // 支付
};

typedef void (^SwitchGameAccountBlock) (YDSDKGetGameData *data);

typedef void (^LoginGameAccountBlock)(YDSDKLoginData* loginData, YDSDKGetGameData *gameData);

@interface YDSDKGlobalMgr : NSObject

+ (instancetype)shareInstance;

- (void)setupGameId:(NSInteger)gameId gameName:(NSString*)gameName gameBundleId:(NSString*)gameBundleId gamePackageName:(NSString*)gamePackageName;

- (void)showAssociateTouch:(BOOL)show;

- (void)pushViewControllerWithType:(YDSDKInterfaceType)type;

- (void)pushViewControllerWithType:(YDSDKInterfaceType)type
                          withData:(YDSDKPlatformPayParamModel*)model
                        withScheme:(NSString*)scheme;

- (void)handleopenURL:(NSURL *)url;

// 切换游戏账号回调
@property (nonatomic, copy) SwitchGameAccountBlock switchGameAccountBlock;

// 登陆游戏账号回调
@property (nonatomic, copy) LoginGameAccountBlock loginGameAccountBlock;

// 上报游戏数据
- (void)upLoadGameDataReport:(YDSDKGameDataReportModel*)model;

// 注销账户
- (void)logout;

- (void)resetData;
@end

NS_ASSUME_NONNULL_END
