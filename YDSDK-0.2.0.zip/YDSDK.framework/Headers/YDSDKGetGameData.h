#import <UIKit/UIKit.h>
#import "YDSDKGetGameLastRoleInfo.h"

@interface YDSDKGetGameData : NSObject

//主账号id
@property (nonatomic, assign) NSInteger accountId;
//游戏账号创建时间
@property (nonatomic, assign) NSInteger createTime;
//冻结状态 0 合法 1 冻结
@property (nonatomic, assign) NSInteger frozenStatus;
//游戏账号id
@property (nonatomic, assign) NSInteger gameAccountId;
//游戏区服
@property (nonatomic, strong) NSString * gameArea;
//游戏id
@property (nonatomic, strong) NSString * gameId;
//游戏状态 0 空闲 1 游戏中
@property (nonatomic, assign) NSInteger gameStatus;
//推广后台账户ID
@property (nonatomic, assign) NSInteger inviterAdminAccountId;
//最新登录账号的角色信息
@property (nonatomic, strong) YDSDKGetGameLastRoleInfo * lastRoleInfo;
//当前游戏账号下的角色总数
@property (nonatomic, assign) NSInteger roleCount;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

-(NSDictionary *)toDictionary;
@end
