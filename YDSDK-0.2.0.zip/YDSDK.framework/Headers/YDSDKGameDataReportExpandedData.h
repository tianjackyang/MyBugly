#import <UIKit/UIKit.h>

@interface YDSDKGameDataReportExpandedData : NSObject


-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

-(NSDictionary *)toDictionary;
@end