#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "YDSDK.h"
#import "YDSDKGameDataReportExpandedData.h"
#import "YDSDKGameDataReportModel.h"
#import "YDSDKGetGameData.h"
#import "YDSDKGetGameLastRoleInfo.h"
#import "YDSDKGlobalMgr.h"
#import "YDSDKLoginData.h"
#import "YDSDKPlatformPayParamModel.h"

FOUNDATION_EXPORT double YDSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char YDSDKVersionString[];

