#import <UIKit/UIKit.h>

@interface YDSDKLoginData : NSObject

@property (nonatomic, assign) NSInteger accountId;
@property (nonatomic, strong) NSString * createTime;
@property (nonatomic, strong) NSString * defaultAvatar;
@property (nonatomic, assign) NSInteger headAdminAccountId;
@property (nonatomic, assign) NSInteger idField;
@property (nonatomic, assign) NSInteger inviterAdminAccountId;
@property (nonatomic, strong) NSString * mobile;
@property (nonatomic, assign) BOOL passedIdCardAuth;
@property (nonatomic, assign) NSInteger status;
@property (nonatomic, strong) NSString * token;
@property (nonatomic, strong) NSString * updateTime;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

-(NSDictionary *)toDictionary;
@end